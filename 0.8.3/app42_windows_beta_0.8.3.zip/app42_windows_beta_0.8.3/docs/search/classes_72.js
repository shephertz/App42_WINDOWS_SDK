var searchData=
[
  ['recommendeditem',['RecommendedItem',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1recommend_1_1_recommender_1_1_recommended_item.html',1,'com::shephertz::app42::paas::sdk::windows::recommend::Recommender']]],
  ['recommender',['Recommender',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1recommend_1_1_recommender.html',1,'com::shephertz::app42::paas::sdk::windows::recommend']]],
  ['recommenderresponsebuilder',['RecommenderResponseBuilder',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1recommend_1_1_recommender_response_builder.html',1,'com::shephertz::app42::paas::sdk::windows::recommend']]],
  ['recommenderservice',['RecommenderService',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1recommend_1_1_recommender_service.html',1,'com::shephertz::app42::paas::sdk::windows::recommend']]],
  ['recommendersimilarity',['RecommenderSimilarity',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1recommend_1_1_recommender_similarity.html',1,'com::shephertz::app42::paas::sdk::windows::recommend']]],
  ['restconnector',['RESTConnector',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1connection_1_1_r_e_s_t_connector.html',1,'com::shephertz::app42::paas::sdk::windows::connection']]],
  ['review',['Review',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1review_1_1_review.html',1,'com::shephertz::app42::paas::sdk::windows::review']]],
  ['reviewresponsebuilder',['ReviewResponseBuilder',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1review_1_1_review_response_builder.html',1,'com::shephertz::app42::paas::sdk::windows::review']]],
  ['reviewservice',['ReviewService',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1review_1_1_review_service.html',1,'com::shephertz::app42::paas::sdk::windows::review']]],
  ['reward',['Reward',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1reward_1_1_reward.html',1,'com::shephertz::app42::paas::sdk::windows::reward']]],
  ['rewardresponsebuilder',['RewardResponseBuilder',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1reward_1_1_reward_response_builder.html',1,'com::shephertz::app42::paas::sdk::windows::reward']]],
  ['rewardservice',['RewardService',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1reward_1_1_reward_service.html',1,'com::shephertz::app42::paas::sdk::windows::reward']]]
];
