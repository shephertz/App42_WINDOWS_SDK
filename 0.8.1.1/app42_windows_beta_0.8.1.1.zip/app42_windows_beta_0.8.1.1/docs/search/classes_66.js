var searchData=
[
  ['feature',['Feature',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1app_tab_1_1_usage_1_1_feature.html',1,'com::shephertz::app42::paas::sdk::windows::appTab::Usage']]],
  ['featuretransaction',['FeatureTransaction',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1app_tab_1_1_bill_1_1_feature_transaction.html',1,'com::shephertz::app42::paas::sdk::windows::appTab::Bill']]],
  ['file',['File',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1upload_1_1_upload_1_1_file.html',1,'com::shephertz::app42::paas::sdk::windows::upload::Upload']]]
];
