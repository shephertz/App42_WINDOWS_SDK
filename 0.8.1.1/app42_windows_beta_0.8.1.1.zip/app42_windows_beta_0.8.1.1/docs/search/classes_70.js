var searchData=
[
  ['payment',['Payment',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1shopping_1_1_cart_1_1_payment.html',1,'com::shephertz::app42::paas::sdk::windows::shopping::Cart']]],
  ['paymentstatus',['PaymentStatus',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1shopping_1_1_payment_status.html',1,'com::shephertz::app42::paas::sdk::windows::shopping']]],
  ['photo',['Photo',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1gallery_1_1_album_1_1_photo.html',1,'com::shephertz::app42::paas::sdk::windows::gallery::Album']]],
  ['photoservice',['PhotoService',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1gallery_1_1_photo_service.html',1,'com::shephertz::app42::paas::sdk::windows::gallery']]],
  ['point',['Point',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1geo_1_1_geo_1_1_point.html',1,'com::shephertz::app42::paas::sdk::windows::geo::Geo']]],
  ['preferencedata',['PreferenceData',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1recommend_1_1_preference_data.html',1,'com::shephertz::app42::paas::sdk::windows::recommend']]],
  ['profile',['Profile',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1user_1_1_user_1_1_profile.html',1,'com::shephertz::app42::paas::sdk::windows::user::User']]],
  ['profiledata',['ProfileData',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1user_1_1_profile_data.html',1,'com::shephertz::app42::paas::sdk::windows::user']]],
  ['pushnotification',['PushNotification',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1push_1_1_push_notification.html',1,'com::shephertz::app42::paas::sdk::windows::push']]],
  ['pushnotificationresponsebuilder',['PushNotificationResponseBuilder',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1push_1_1_push_notification_response_builder.html',1,'com::shephertz::app42::paas::sdk::windows::push']]],
  ['pushnotificationservice',['PushNotificationService',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1push_1_1_push_notification_service.html',1,'com::shephertz::app42::paas::sdk::windows::push']]]
];
