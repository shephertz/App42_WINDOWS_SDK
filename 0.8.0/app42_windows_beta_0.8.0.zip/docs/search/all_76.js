var searchData=
[
  ['validatemax',['ValidateMax',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1util_1_1_util.html#a5c491eb9453b76a3bb237800c41f790a',1,'com::shephertz::app42::paas::sdk::windows::util::Util']]],
  ['value',['value',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1game_1_1_game_1_1_score.html#a87a22d835598c6807c2420cd5126b94d',1,'com.shephertz.app42.paas.sdk.windows.game.Game.Score.value()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1recommend_1_1_recommender_1_1_recommended_item.html#a0bc1b33be46d162cf5b1a082c4f35b9e',1,'com.shephertz.app42.paas.sdk.windows.recommend.Recommender.RecommendedItem.value()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1session_1_1_session_1_1_attribute.html#a4a3d0eb8ef4134f38b7d954da773f7ab',1,'com.shephertz.app42.paas.sdk.windows.session.Session.Attribute.value()']]],
  ['video',['VIDEO',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1upload_1_1_upload_file_type.html#a6828395e149723d8f17ffe3fda3a7108',1,'com::shephertz::app42::paas::sdk::windows::upload::UploadFileType']]]
];
