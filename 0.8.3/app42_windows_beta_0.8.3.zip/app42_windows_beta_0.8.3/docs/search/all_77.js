var searchData=
[
  ['width',['width',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1image_processor_1_1_image.html#a9f4dbb0ebda41cb89051593801b905bd',1,'com::shephertz::app42::paas::sdk::windows::imageProcessor::Image']]]
];
