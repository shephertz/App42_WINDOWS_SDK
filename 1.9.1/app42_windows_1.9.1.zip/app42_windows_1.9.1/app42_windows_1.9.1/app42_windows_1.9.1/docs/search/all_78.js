var searchData=
[
  ['x',['x',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1image_processor_1_1_image.html#add719d2dcf3b3c44c6b861bb0af316cf',1,'com::shephertz::app42::paas::sdk::windows::imageProcessor::Image']]],
  ['xml',['XML',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1upload_1_1_upload_file_type.html#a0e1d94743cbfa4cbf0b6b4cbcb635614',1,'com::shephertz::app42::paas::sdk::windows::upload::UploadFileType']]]
];
