var searchData=
[
  ['quantity',['quantity',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1shopping_1_1_cart_1_1_item.html#a8593d495ecddcd8fc0ecd1f6bc6286a8',1,'com::shephertz::app42::paas::sdk::windows::shopping::Cart::Item']]],
  ['queuename',['queueName',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1message_1_1_queue.html#aced71d0da62b1cbf3b004dd4b1e08912',1,'com::shephertz::app42::paas::sdk::windows::message::Queue']]],
  ['queuetype',['queueType',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1message_1_1_queue.html#a22cccf74608428a201d692786b5ae252',1,'com::shephertz::app42::paas::sdk::windows::message::Queue']]]
];
