var searchData=
[
  ['debug',['debug',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1_app42_log.html#ab70ce701e37bf16e89e0cf447db264e5',1,'com.shephertz.app42.paas.sdk.windows.App42Log.debug()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1log_1_1_log_service.html#ace2f86ba97c2b1eb088ab9df04903f58',1,'com.shephertz.app42.paas.sdk.windows.log.LogService.Debug()']]],
  ['decreasequantity',['DecreaseQuantity',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1shopping_1_1_cart_service.html#ad73c94e6340f10297fda169de6f13771',1,'com::shephertz::app42::paas::sdk::windows::shopping::CartService']]],
  ['deductscore',['DeductScore',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1game_1_1_score_service.html#ad5e53e3bcc6e6557a7d46a19c3d17c4b',1,'com::shephertz::app42::paas::sdk::windows::game::ScoreService']]],
  ['deletedocumentbyid',['DeleteDocumentById',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1storage_1_1_storage_service.html#a007c2eec36b395b37b96dadfff321592',1,'com::shephertz::app42::paas::sdk::windows::storage::StorageService']]],
  ['deletepreferencefile',['DeletePreferenceFile',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1recommend_1_1_recommender_service.html#a4929a23e22a697cdaf6db11e752ccf9a',1,'com::shephertz::app42::paas::sdk::windows::recommend::RecommenderService']]],
  ['deletepullqueue',['DeletePullQueue',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1message_1_1_queue_service.html#aab7927f2c04fff25aecdd099727ef213',1,'com::shephertz::app42::paas::sdk::windows::message::QueueService']]],
  ['deletestorage',['DeleteStorage',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1geo_1_1_geo_service.html#abe596b7470b1ff1b62b4a69aeae6ef96',1,'com::shephertz::app42::paas::sdk::windows::geo::GeoService']]],
  ['deleteuser',['DeleteUser',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1user_1_1_user_service.html#a9d4eefc379074f616207a4a640d96b50',1,'com::shephertz::app42::paas::sdk::windows::user::UserService']]]
];
