var searchData=
[
  ['gamename',['gameName',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1reward_1_1_reward.html#ab0b81a4add2f2b32bb2c2b063840ae3a',1,'com::shephertz::app42::paas::sdk::windows::reward::Reward']]],
  ['gb',['GB',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1app_tab_1_1_usage_band_width.html#a49bb784f7fe5f60b98a8c67761d0fbb3',1,'com.shephertz.app42.paas.sdk.windows.appTab.UsageBandWidth.GB()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1app_tab_1_1_usage_storage.html#a7a0ba18c4f1a0893b0d5b748a11637d4',1,'com.shephertz.app42.paas.sdk.windows.appTab.UsageStorage.GB()']]]
];
