var searchData=
[
  ['rank',['rank',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1game_1_1_game_1_1_score.html#a64f9d7fe46ccee833be96cb396f6cbdf',1,'com::shephertz::app42::paas::sdk::windows::game::Game::Score']]],
  ['rating',['rating',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1review_1_1_review.html#a4f026c3990aae3bff0981b2862928d65',1,'com::shephertz::app42::paas::sdk::windows::review::Review']]],
  ['recommendeditemlist',['recommendedItemList',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1recommend_1_1_recommender.html#a73d116393ee259d43ee20e905b5a3d1f',1,'com::shephertz::app42::paas::sdk::windows::recommend::Recommender']]],
  ['reviewid',['reviewId',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1review_1_1_review.html#a82543104e244546d03736ca33c5cb5d0',1,'com::shephertz::app42::paas::sdk::windows::review::Review']]],
  ['rolelist',['roleList',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1user_1_1_user.html#a6bb27622a3472f762357934d5d557d0e',1,'com.shephertz.app42.paas.sdk.windows.user.User.roleList()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1user_1_1_user_1_1_profile.html#aaf837eca008e9181c241f5fd1a5c2d49',1,'com.shephertz.app42.paas.sdk.windows.user.User.Profile.roleList()']]]
];
