var searchData=
[
  ['score',['Score',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1game_1_1_game_1_1_score.html',1,'com::shephertz::app42::paas::sdk::windows::game::Game']]],
  ['scoreboardservice',['ScoreBoardService',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1game_1_1_score_board_service.html',1,'com::shephertz::app42::paas::sdk::windows::game']]],
  ['scoreservice',['ScoreService',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1game_1_1_score_service.html',1,'com::shephertz::app42::paas::sdk::windows::game']]],
  ['serviceapi',['ServiceAPI',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1_service_a_p_i.html',1,'com::shephertz::app42::paas::sdk::windows']]],
  ['session',['Session',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1session_1_1_session.html',1,'com::shephertz::app42::paas::sdk::windows::session']]],
  ['sessionresponsebuilder',['SessionResponseBuilder',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1session_1_1_session_response_builder.html',1,'com::shephertz::app42::paas::sdk::windows::session']]],
  ['sessionservice',['SessionService',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1session_1_1_session_service.html',1,'com::shephertz::app42::paas::sdk::windows::session']]],
  ['social',['Social',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1social_1_1_social.html',1,'com::shephertz::app42::paas::sdk::windows::social']]],
  ['socialresponsebuilder',['SocialResponseBuilder',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1social_1_1_social_response_builder.html',1,'com::shephertz::app42::paas::sdk::windows::social']]],
  ['socialservice',['SocialService',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1social_1_1_social_service.html',1,'com::shephertz::app42::paas::sdk::windows::social']]],
  ['storage',['Storage',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1storage_1_1_storage.html',1,'com::shephertz::app42::paas::sdk::windows::storage']]],
  ['storageresponsebuilder',['StorageResponseBuilder',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1storage_1_1_storage_response_builder.html',1,'com::shephertz::app42::paas::sdk::windows::storage']]],
  ['storageservice',['StorageService',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1storage_1_1_storage_service.html',1,'com::shephertz::app42::paas::sdk::windows::storage']]]
];
