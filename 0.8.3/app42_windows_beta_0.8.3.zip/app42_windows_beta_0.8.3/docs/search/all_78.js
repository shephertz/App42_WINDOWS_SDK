var searchData=
[
  ['x',['x',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1image_processor_1_1_image.html#a9abf21c7b37d6b658358f167db7e49a7',1,'com::shephertz::app42::paas::sdk::windows::imageProcessor::Image']]],
  ['xml',['XML',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1upload_1_1_upload_file_type.html#a86a75ca1900e14594278940516804253',1,'com::shephertz::app42::paas::sdk::windows::upload::UploadFileType']]]
];
