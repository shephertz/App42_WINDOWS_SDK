var searchData=
[
  ['kb',['KB',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1app_tab_1_1_bandwidth_unit.html#a980dffc12f9cce123d39880368900333',1,'com.shephertz.app42.paas.sdk.windows.appTab.BandwidthUnit.KB()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1app_tab_1_1_storage_unit.html#a099fa0617a2486fb89ed11220a685483',1,'com.shephertz.app42.paas.sdk.windows.appTab.StorageUnit.KB()']]],
  ['key',['key',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1app_tab_1_1_bill_1_1_license_transaction_1_1_transaction.html#a762033e1ee026623bfba938862e20c97',1,'com.shephertz.app42.paas.sdk.windows.appTab.Bill.LicenseTransaction.Transaction.key()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1app_tab_1_1_license.html#a0054b0bfdb640649a654fb6b3566f7a0',1,'com.shephertz.app42.paas.sdk.windows.appTab.License.key()']]]
];
