var searchData=
[
  ['jsondocument',['JSONDocument',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1storage_1_1_storage_1_1_j_s_o_n_document.html#ac7f793971d7cd8a04fe2726cbb462db9',1,'com::shephertz::app42::paas::sdk::windows::storage::Storage::JSONDocument']]]
];
