var searchData=
[
  ['binary',['BINARY',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1upload_1_1_upload_file_type.html#a0119da8bbb753e6610f40f2257592522',1,'com::shephertz::app42::paas::sdk::windows::upload::UploadFileType']]],
  ['body',['body',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1email_1_1_email.html#af15fa53827883db309fd4f9f6daa3c67',1,'com::shephertz::app42::paas::sdk::windows::email::Email']]]
];
