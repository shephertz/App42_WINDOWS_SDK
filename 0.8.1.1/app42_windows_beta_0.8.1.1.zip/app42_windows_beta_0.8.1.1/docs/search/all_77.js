var searchData=
[
  ['width',['width',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1image_processor_1_1_image.html#a20586eea70ef97364ab1593c899557c7',1,'com::shephertz::app42::paas::sdk::windows::imageProcessor::Image']]],
  ['wp7',['WP7',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1push_1_1_device_type.html#aa92dd2ea46073043ff7d6de2df90da41',1,'com::shephertz::app42::paas::sdk::windows::push::DeviceType']]]
];
