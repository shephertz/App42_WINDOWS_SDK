var searchData=
[
  ['rank',['rank',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1game_1_1_game_1_1_score.html#a9e5b5d43ae8af7fc79dc49a45e3dd1d3',1,'com::shephertz::app42::paas::sdk::windows::game::Game::Score']]],
  ['rating',['rating',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1review_1_1_review.html#a4f01605fc7c6c63770b1745b57cc5f0e',1,'com::shephertz::app42::paas::sdk::windows::review::Review']]],
  ['recommendeditemlist',['recommendedItemList',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1recommend_1_1_recommender.html#ad433a277eeba42d0e85b93d7ea265695',1,'com::shephertz::app42::paas::sdk::windows::recommend::Recommender']]],
  ['remove',['REMOVE',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1app_tab_1_1_charge_type.html#a33a568eea0be3cd5c201d615b73cfd42',1,'com::shephertz::app42::paas::sdk::windows::appTab::ChargeType']]],
  ['reviewid',['reviewId',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1review_1_1_review.html#a77305b8fdcd2eac999494b72b6689524',1,'com::shephertz::app42::paas::sdk::windows::review::Review']]],
  ['rolelist',['roleList',['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1user_1_1_user.html#a528f61b9c898ff4f77f83f4df5b4803e',1,'com.shephertz.app42.paas.sdk.windows.user.User.roleList()'],['../classcom_1_1shephertz_1_1app42_1_1paas_1_1sdk_1_1windows_1_1user_1_1_user_1_1_profile.html#a528f61b9c898ff4f77f83f4df5b4803e',1,'com.shephertz.app42.paas.sdk.windows.user.User.Profile.roleList()']]]
];
